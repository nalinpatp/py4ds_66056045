"""
Exercise 18 : Buy 8 get 1 free
"""


def get_cost_of_coffee(param, param1):
    pass
